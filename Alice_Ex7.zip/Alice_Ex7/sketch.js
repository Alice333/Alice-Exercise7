var font1; //Disney Font
var font2; //Xiomara Font
var font3; //NexaRust
var font4; //Candy
var font5; //Cookie Monster
var themePic;
var book;
var howl1;
var hug2;
var hug1;
var balcony;
var castle;

//variable for click change
var a=0;
var a1= true;
var a2= true;
var a3= true;
var a4= true;

function preload(){
  //load fonts
  font1=loadFont('data/New_Walt_Disney.ttf');
  font2=loadFont('data/Xiomara-Script.ttf');
  font3=loadFont('data/NexaRustHandmade.otf');
  font4=loadFont('data/CANDY.otf');
  font5=loadFont('data/CookieMonster.ttf');
  
  //load images
  themePic=loadImage('data/Theme1.jpg');
  book=loadImage('data/OpenBook.jpg');
  howl1=loadImage('data/Howl1.jpg');
  hug2=loadImage('data/Hug2.png');
  hug1=loadImage('data/Hug1.jpg');
  balcony=loadImage('data/balcony.jpg');
  castle=loadImage('data/Castle.jpg');
}


function setup() {
  createCanvas(800,500);
  background(227,242,227);
  
  //String Set
  string1='Howl\'s Moving Castle';
  
}

function draw() {
  console.log(mouseX);
  console.log(mouseY);
  
  //introduction page
  if(frameCount<25){
    //images
    image(themePic, 0, 0);
    
    push();
    scale(1/10);
    image(book,7400,4450);
    pop();
    
    //text1
    strokeWeight(2);
    fill(236,137,212);
    stroke(236,137,212);
    textFont(font1,60);
    textAlign(RIGHT);
    text(string1,788,94);
    
    //text2
    strokeWeight(2);
    fill(215,121,216);
    stroke(215,121,216);
    textFont(font2,40);
    textAlign(RIGHT);
    text("Art Gallery",679,264);
    
    //text3
    strokeWeight(1);
    fill(215,121,216);
    stroke(148,255,105);
    textFont(font3,18);
    textAlign(RIGHT);
    text("Click to begin the Gallery",730,472);
    
  }//intro, frameCount<100
  
  
  if(frameCount>25){
    if((a1==true)&&(mouseIsPressed)&&(mouseX>740)&&(mouseX<800)&&(mouseY>443)&&(mouseY<800)){
    a=1;
  }
    if(a==1){
    background(227,242,227);
    
    //image
    push();
    scale(1/4);
    image(howl1,150,90);
    pop();
    
    push();
    scale(1/10);
    image(book,5930,4450);
    pop();
    
    //text1: Howl, title
    strokeWeight(2);
    fill(236,137,212);
    stroke(236,137,212);
    textFont(font4,150);
    textAlign(RIGHT);
    text('Howl',788,94);
    
    //text2
    strokeWeight(1);
    fill(225,102,97);
    textFont(font3,30);
    textAlign(RIGHT);
    text('Lonely prince\n and his moving castle, \nwhose heart never settle...', 766,258);
    
    a1=false;
    
    if((a2==true)&&(mouseIsPressed)&&(mouseX>593)&&(mouseX<654)&&(mouseY>445)&&(mouseY<498)){
      a=2;
    }
    
    
  }//a=1
  
  if(a==2){
    background(227,242,227);
    image(hug2,147,28);
    
    push();
    scale(1/10);
    image(book,1,4450);
    pop();
    
    //text
    strokeWeight(1);
    fill(236,137,212);
    stroke(236,137,212);
    textFont(font3,20);
    textAlign(RIGHT);
    text('Until he met Sophie, a common village girl.\nThey fall in love. ',610,438);
    
    a2=false;
    if((a3==true)&&(mouseIsPressed)&&(mouseX>1)&&(mouseX<60)&&(mouseY>444)&&(mouseY<498)){
      a=3;
    }
    
  }//a=2
  
  if(a==3){
    background(227,242,227);
    
    push();
    scale(3/5);
    image(hug1,110,22);
    pop();
    
    push();
    scale(1/10);
    image(book,3710,4450);
    pop();
    
     //text
    strokeWeight(1);
    fill(236,137,212);
    stroke(236,137,212);
    textFont(font3,20);
    textAlign(CENTER);
    text('The country was on a war,\nbut the howl was a sorcerer. \nHe used his power to defeat the enemy and protect his girl.',386,380);
    
    a3=false;
    if((a4==true)&&(mouseIsPressed)&&(mouseX>370)&&(mouseX<432)&&(mouseY>444)&&(mouseY<498)){
      a=4;
    }
  }//a=3
  
  if(a==4){
    background(227,242,227);
     
    push();
    scale(4/5);
    image(castle,0,0);
    pop();
    
    push();
    scale(1/3);
    image(balcony,1200,750);
    pop();
    
     //text1
    strokeWeight(1);
    fill(216,102,126);
    stroke(236,137,212);
    textFont(font3,20);
    textAlign(CENTER);
    text('And they lived \nhappily together.',642,68);
    
     //text2
    strokeWeight(3);
    fill(87,169,202);
    stroke(240,196,221);
    textFont(font1,60);
    textAlign(CENTER);
    text('~End~',195,398);
    
    //text3
    strokeWeight(3);
    fill(87,169,202);
    stroke(240,196,221);
    textFont(font5,25);
    textAlign(LEFT);
    text('To be continued...',15,480);
   
    
  }//a=4
}//frameCount>25 ?
}//draw