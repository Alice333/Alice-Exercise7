var font1; //Disney Font
var font2; //Xiomara Font
var font3; //NexaRust
var themePic;
var book;


function preload(){
  //load fonts
  font1=loadFont('data/New_Walt_Disney.ttf');
  font2=loadFont('data/Xiomara-Script.ttf');
  font3=loadFont('data/NexaRustHandmade.otf');
  
  //load images
  themePic=loadImage('data/Theme1.jpg');
  book=loadImage('data/OpenBook.jpg');
  
}


function setup() {
  createCanvas(800,500);
  background(227,242,227);
  
  //String Set
  string1='Howl\'s Moving Castle';
  
}

function draw() {
  console.log(mouseX);
  console.log(mouseY);
  
  //introduction page
  if(frameCount<100){
    //images
    image(themePic, 0, 0);
    
    push();
    scale(1/10);
    image(book,7400,4450);
    pop();
    
    //text1
    strokeWeight(2);
    fill(236,137,212);
    stroke(236,137,212);
    textFont(font1,60);
    textAlign(RIGHT);
    text(string1,788,94);
    
    //text2
    strokeWeight(2);
    fill(215,121,216);
    stroke(215,121,216);
    textFont(font2,40);
    textAlign(RIGHT);
    text("Art Gallery",679,264);
    
    //text3
    strokeWeight(1);
    fill(215,121,216);
    stroke(148,255,105);
    textFont(font3,18);
    textAlign(RIGHT);
    text("Click to begin the Gallery",730,472);
    
  }//intro

  
  
}